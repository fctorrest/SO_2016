package personas;

import banco.Banco;

public class Persona implements Runnable{
	private Banco bancoAsociado;
	private int numeroTransacciones;
	private int[] transacciones;
	
	public void setBancoAsociado(Banco b){
		this.bancoAsociado = b;
	}
	
	public Banco getBancoAsociado(){
		return this.bancoAsociado;
	}
	
	public void setNumeroTransacciones(int numeroTransacciones){
		this.numeroTransacciones = numeroTransacciones;
	}
	
	public int getNumeroTransacciones(){
		return this.numeroTransacciones;
	}
	
	public void setTransacciones(int[] transacciones){
		this.transacciones = transacciones;
	}
	
	public int[] getTransacciones(){
		return this.transacciones;
	}
	
	
	public Persona(int numeroTransacciones, Banco b){
		this.setNumeroTransacciones(numeroTransacciones);
		this.transacciones = new int[this.getNumeroTransacciones()];
		this.setBancoAsociado(b);
	}
	
	public void realizarTransacciones() throws InterruptedException{
		for(int i=0; i<this.getNumeroTransacciones(); i++){
			int valorTransaccion = this.getTransacciones()[i];
			int valorActualCuenta = (this.getBancoAsociado()).getValorCuenta();
			valorActualCuenta = valorActualCuenta + valorTransaccion;
			(this.getBancoAsociado()).setValorCuenta(valorActualCuenta);
		}
	}
	
	
	
	@Override
	public void run() {
		try {
			this.realizarTransacciones();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

}
