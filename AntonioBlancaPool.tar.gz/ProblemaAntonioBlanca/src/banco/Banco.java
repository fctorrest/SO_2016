package banco;

import personas.Persona;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Banco {
	private int valorCuenta;
	
	public void setValorCuenta(int valorNuevo){
		this.valorCuenta = valorNuevo;
	}
	
	public int getValorCuenta(){
		return this.valorCuenta;
	}
	
	public Banco(){
		this.setValorCuenta(0);
	}
	
	public void asignarTransacciones(Persona p, int numeroTransacciones, Scanner sc){
		int[] transacciones = new int[numeroTransacciones];
		for(int i=0; i<numeroTransacciones; i++){
			transacciones[i] = sc.nextInt();
		}
		p.setTransacciones(transacciones);
	}
	
	public static void main(String[] args) throws FileNotFoundException, InterruptedException{
		Scanner sc = new Scanner(new File("operaciones.txt"));
		Banco Banco = new Banco();
		ExecutorService executor = Executors.newFixedThreadPool(2);
		Persona Antonio = new Persona(sc.nextInt(), Banco);
		Persona Blanca = new Persona(sc.nextInt(), Banco);
		Banco.asignarTransacciones(Antonio, Antonio.getNumeroTransacciones(), sc);
		Banco.asignarTransacciones(Blanca, Blanca.getNumeroTransacciones(), sc);
		Thread operacionesAntonio = new Thread(Antonio);
		Thread operacionesBlanca = new Thread(Blanca);
		executor.execute(operacionesAntonio);
		executor.execute(operacionesBlanca);
		executor.shutdown();
		System.out.println("El estado final de la cuenta es "+Banco.getValorCuenta());
	}

}
